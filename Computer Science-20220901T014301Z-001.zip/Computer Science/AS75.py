denary = int(input("give denary"))

answer = bcd.denary(0,0000)
answer = bcd.denary(1,0001)
answer = bcd.denary(2,0010)
answer = bcd.denary(3,0011)
answer = bcd.denary(4,0100)
answer = bcd.denary(5,0101)
answer = bcd.denary(6,0110)
answer = bcd.denary(7,0111)
answer = bcd.denary(8,1000)
answer = bcd.denary(9,1001)
print(answer)

