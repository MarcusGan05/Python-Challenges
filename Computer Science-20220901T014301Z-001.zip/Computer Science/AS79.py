#Write a procedure make_it_laugh(string) to replace all vowels in an input string with "haha". Print the modified string after to verify your procedure has worked.
word = input("Choose a sentence")
vowels = ["a","e","i","o","u"]

for i in word:

    if i in vowels:
        print("haha")
    else:
        print(i)