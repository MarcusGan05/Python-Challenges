#clear the terminal
def clearscreen():
        for i in range(100):
            print("")
print("clear me away")
