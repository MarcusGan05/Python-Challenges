import datetime

points = 0
lives = 3
questions =["1+1","2+2","5x5","differentiate (2x^5-x+3)/x^2" ]
answers = ["2","4","25","(6x^5+x-6)/x^3"]
z = len(questions)

for i in range(z):
    first = datetime.datetime.now()
    print(questions[i])
    answer = input("what is answer")
    later = datetime.datetime.now()
    timediff = later-first
    timediff_s = timediff.total_seconds()
    if answers[i] == answer :
        points = points + 100 -timediff_s*50
    else:
        lives = lives-1

    print(points)
    print(lives)