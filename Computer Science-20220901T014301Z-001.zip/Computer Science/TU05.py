test = input("Is it raining? y/n ")
if test in ["y","Y","Yes","yes"]:
    print("Oh dear, no football today!")
else:
    print("oogers")