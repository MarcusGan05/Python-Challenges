x = "string"
print(x[-1::-1])
print(x)
print(x[::2])