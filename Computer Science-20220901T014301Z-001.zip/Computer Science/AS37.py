mystring = input('string pls')
consonants = 'bcdfghjklmnpqrstuvwxyz'
rovarword = []
def rovar(mystring):
    for i in mystring:
        if i not in consonants:
            rovarword.append(i)
        else:
            rovarword.append(i)
            rovarword.append('o')
            rovarword.append(i)
    print(rovarword)

rovar(mystring)