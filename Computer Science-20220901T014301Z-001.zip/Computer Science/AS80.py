
def Circle_perimeter(x):
    print(x*2*3.14159,"is your perimeter")
def Circle_area(x):
    print(3.14159*x**2,"is your area")