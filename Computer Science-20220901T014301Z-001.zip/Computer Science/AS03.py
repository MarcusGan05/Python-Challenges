string = input("GIVE JOKE")
x = len(string)
reverse_string = string[-1:-x-1:-1]
print(reverse_string)