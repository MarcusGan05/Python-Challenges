Kaixianglowborn = 0
MyAge = int(input('When were you born?'))
AgeDifference = MyAge - Kaixianglowborn
print("Kai is ",AgeDifference,"percent cooler than you")