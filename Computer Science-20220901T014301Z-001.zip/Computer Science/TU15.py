x=3.33333333
print(x)
x=round(x,3)
print(x)

print(round(x,1))

print (x)