list = ["kai xiang","leon","alex watts","mr abela","maxjamiebby"]
print(list[0:4])

newlist = input("Add a character of your choice")

list.append(newlist)
print(list)