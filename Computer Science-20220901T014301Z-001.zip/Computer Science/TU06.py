MYHEIGHT = 240
YOURHEIGHT = int(input("HOW SHORT ARE YOU(cm)?"))
if YOURHEIGHT > MYHEIGHT:
    print("YOU ARE WAY TOO TALL!")
else:
    print("hahahha midget")