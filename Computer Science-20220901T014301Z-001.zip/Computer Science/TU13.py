list = [1,2,3,4,5]
print (sum(list))

print(min(list))
print(max(list))
print(len(list))
print(sum(list)/len(list))
print(list)