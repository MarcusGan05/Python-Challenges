stringe = input("string please")
if len(stringe) == 1:
    print("yes godo")