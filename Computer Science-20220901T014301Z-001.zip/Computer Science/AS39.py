import random
song =[["song"]*10,["song2"]*10,["song3"]*10,["song4"]*10,["song5"]*10,["song6"]*10,["song7"]*10,["song8"]*10,["song9"]*10,["song10"]*10]
#print(song)

playlist =[]

for i in range(10):
    x = len(playlist)
    while x <21:
        artist = random.randint(0,9)
        artist1 = random.randint(0,9)
        artist2 = random.randint(0,9)
        if artist != artist1 and artist != artist2:
            playlist.append(song[artist][1])
        if artist1 != artist and artist1 != artist2:
            playlist.append(song[artist1][1])
        if artist2 != artist1 and artist2 != artist1:
            playlist.append(song[artist2][1])
        x = len(playlist)


print(playlist)

