x = int(input("give denary"))
y = 0
x = bin(x)
print(x)
for i in x:
    if i==1:
        y=y+1
    else:
        pass

if (y%2!=0 and y==0):
    print('even 1s')
else:
    print('odd 1s')