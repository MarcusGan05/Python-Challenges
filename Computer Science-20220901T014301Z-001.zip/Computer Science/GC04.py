n = int(input("how big do you want your pyramid"))


for i in range(0,n):
    for x in range (0,n):
        print(end="")
    n=n-1

    for x in range(0,i+1):
        print("*", end="")
    print ("\r")