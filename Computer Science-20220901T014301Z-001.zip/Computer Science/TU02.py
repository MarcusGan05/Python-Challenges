whatsup = input('Whats is up guys?')

print('Hello, this is whats up:',whatsup)