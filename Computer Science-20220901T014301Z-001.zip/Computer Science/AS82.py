#string reverse

string = input("GIVE STRING")
x = len(string)
reverse_string = string[-1:-x-1:-1]
print(reverse_string)
