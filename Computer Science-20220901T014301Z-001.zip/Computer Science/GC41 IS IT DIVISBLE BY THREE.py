numbre = int(input('what is your integer'))
if numbre%3 == 0:
    print('your number is  divisible by three')
else:
    print('your number is awful')