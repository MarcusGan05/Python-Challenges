import random

words = ["binary","hexadecimal","Byte","Transmission","Browser","Boolean","String","Logic Gate", "Von Neuman"]

wordss = random.choice(words)
print(wordss)


x = (len(wordss))

for i in range(x,0,-1):
    print("_", end = '')




lives = 5
while lives > 0:
    your_guess = input("Guess the computer science word")
    if your_guess == wordss:
        print("YOU WIN")
    else:
        lives = lives-1
        print(lives,"lives left")


    for char in wordss:
        if char in your_guess:
            print (char)
        else :
            print ("_")
    # x = x - 1