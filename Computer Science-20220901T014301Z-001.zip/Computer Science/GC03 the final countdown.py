import time
for i in range(5,0,-1):
    time.sleep(1)
    print(i)
print("blast off")
