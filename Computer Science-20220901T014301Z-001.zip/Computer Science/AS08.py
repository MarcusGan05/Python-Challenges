#Rock paper scissors
import random

rps = random.choice(["Rock","Paper","Scissors"])
myguess = input("Rock, Paper, or Scissors")
#paper
if myguess in ["Paper","paper"] and rps == "Scissors":
    print("YOU LOSE")

if myguess in ["Paper","paper"] and rps == "Rock":
    print("YOU WIN")

if myguess in ["Paper","paper"] and rps == "Paper":
    print("TIE")
#scissors

if myguess in ["Scissors","scissors"] and rps == "Rock":
    print("YOU LOSE")

if myguess in ["Scissors","scissors"] and rps == "Paper":
    print("YOU WIN")

if myguess in ["Scissors","scissors"] and rps == "Scissors":
    print("TIE")
#Rock
if myguess in ["Rock","rock"] and rps == "Paper":
    print("YOU LOSE")

if myguess in ["Rock","rock"] and rps == "Scissors":
    print("YOU WIN")

if myguess in ["Rock","rock"] and rps == "Rock":
    print("TIE")

