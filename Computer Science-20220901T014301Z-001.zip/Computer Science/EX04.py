Give = input("give normal code")
morse = ['.-','-...','-.-.', '-..', '.','..-.', '--.','....','..', '.---', '-.-', '.-..', '--',  '-.', '---',  '.--.',  '--.-','.-.',  '...',  '-', '..-',  '...-',  '.--','-..-',  '-.--', '--..']
alphabet = ['a','b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
y = len(Give)
for i in range(y):
    x = (alphabet.index(Give[i]))
    print(morse[x])


give2 = input("morse code")
y2 = len(give2)
for i in range(y2):
    x2 = morse.index(give2[i])
    print(alphabet[x2])