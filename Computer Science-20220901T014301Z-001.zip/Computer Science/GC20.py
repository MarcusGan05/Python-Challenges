import time

print('it is 2 pm')
time.sleep(51*60)
print ('WAKE UP')