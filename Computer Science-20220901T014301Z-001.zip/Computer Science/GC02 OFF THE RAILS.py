theirtime = int(input('What time is it right now'))
amorpm = input('Is it in am or pm')
if theirtime and amorpm == "pm":
    print ('it is ',theirtime+12)
else:
    print('it is', theirtime)