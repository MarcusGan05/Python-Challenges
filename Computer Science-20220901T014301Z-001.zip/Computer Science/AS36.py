#Write a program that takes a list of numbers (for example, a = [5, 10, 15, 20, 25]) and makes a new list of only the first and last elements of the given list.	
list1 = [5, 10, 15, 20, 25]
x = len(list1)
list2 = []

list2.append(list1[0])
list2.append(list1[x-1])
print(list2)