while True:
    favsubject = input('What is your favourite subject')
    if favsubject in ["Computer science", "computer science", "Computer Science"]:
        break