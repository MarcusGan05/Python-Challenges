x = [1,2,3,4]
position = 0
want = int(input("number from 1 to 4"))
for i in range(len(x)):
    if x[i]== want:
        print("found it at",position+1)
        break
    else:
        position = position + 1
        continue


