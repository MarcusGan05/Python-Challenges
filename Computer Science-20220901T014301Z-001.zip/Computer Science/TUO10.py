import random
mynumber = random.uniform(0.1, 9.9)
print(mynumber)

choosename = ["Jon","jonny","john","jone"]