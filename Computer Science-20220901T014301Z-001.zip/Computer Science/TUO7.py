for i in range (1,101):
    print (i)

for i in range (0,100,2):
    print(i)

for i in range(1000,1,-10):
    print(i)