print("eazy")
print(355/113)
print(22/7)